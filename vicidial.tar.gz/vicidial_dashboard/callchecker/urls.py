from django.urls import path
from . import views  # Import views module

urlpatterns = [
    path('', views.recent_calls, name='recent_calls'),  # root URL
    path('recent-termination-reasons/', views.call_termination_reasons, name='call_termination_reasons'),
]

