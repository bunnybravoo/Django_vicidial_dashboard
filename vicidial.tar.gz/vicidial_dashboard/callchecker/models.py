from django.db import models

class VicidialCloserLog(models.Model):
    closecallid = models.AutoField(primary_key=True)
    lead_id = models.IntegerField()
    list_id = models.IntegerField(null=True, blank=True)
    campaign_id = models.CharField(max_length=20, null=True, blank=True)
    call_date = models.DateTimeField(null=True, blank=True)
    start_epoch = models.BigIntegerField(null=True, blank=True)
    end_epoch = models.BigIntegerField(null=True, blank=True)
    length_in_sec = models.IntegerField(null=True, blank=True)
    status = models.CharField(max_length=10, null=True, blank=True)
    phone_code = models.CharField(max_length=10, null=True, blank=True)
    phone_number = models.CharField(max_length=20, null=True, blank=True)
    user = models.CharField(max_length=10, null=True, blank=True)
    comments = models.CharField(max_length=255, null=True, blank=True)
    processed = models.CharField(max_length=1, null=True, blank=True)
    queue_seconds = models.FloatField(null=True, blank=True)
    user_group = models.CharField(max_length=20, null=True, blank=True)
    xfercallid = models.IntegerField(null=True, blank=True)
    term_reason = models.CharField(max_length=20, null=True, blank=True)
    uniqueid = models.CharField(max_length=50, null=True, blank=True)
    agent_only = models.CharField(max_length=5, null=True, blank=True)
    queue_position = models.IntegerField(null=True, blank=True)
    called_count = models.IntegerField(null=True, blank=True)

    class Meta:
        db_table = 'vicidial_closer_log'


        

