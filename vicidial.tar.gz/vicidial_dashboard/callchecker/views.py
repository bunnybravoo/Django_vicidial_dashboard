from django.shortcuts import render
from django.db.models import Count
from collections import defaultdict
from callchecker.models import VicidialCloserLog
from .forms import YourDateRangeForm
from django.core.paginator import Paginator
from django.utils import timezone
import datetime

def recent_calls(request):
    form = YourDateRangeForm(request.GET or None)

    calls_qs = VicidialCloserLog.objects.all()

    # Filter by date range if provided and form is valid
    if form.is_valid():
        start_date = form.cleaned_data.get('start_date')
        end_date = form.cleaned_data.get('end_date')

        if start_date:
            calls_qs = calls_qs.filter(call_date__gte=start_date)
        if end_date:
            calls_qs = calls_qs.filter(call_date__lte=end_date)
    else:
        start_date = end_date = None

    # Get top 20 phone numbers with more than 1 call, ordered by attempts descending
    repeated_calls_data = calls_qs.values('phone_number').annotate(
        attempts=Count('closecallid')
    ).filter(attempts__gt=1).order_by('-attempts')[:20]

    # Prepare a list of phone numbers to fetch their call dates
    phone_numbers = [item['phone_number'] for item in repeated_calls_data]

    # Get all calls matching those phone numbers within the filtered queryset
    calls_for_numbers = calls_qs.filter(phone_number__in=phone_numbers)

    # Map phone_number to list of call_date
    dates_dict = defaultdict(list)
    for call in calls_for_numbers:
        dates_dict[call.phone_number].append(call.call_date)

    # Build repeated_calls list for template with dates sorted descending (latest first)
    repeated_calls = []
    for item in repeated_calls_data:
        sorted_dates = sorted(dates_dict[item['phone_number']], reverse=True)
        repeated_calls.append({
            'phone_number': item['phone_number'],
            'attempts': item['attempts'],
            'dates': sorted_dates,
            'latest_call': sorted_dates[0] if sorted_dates else None
        })

    # Sort repeated_calls by latest_call descending (newest first)
    repeated_calls.sort(key=lambda x: x['latest_call'] or '', reverse=True)

    # Fetch latest 100 calls for main table (optional)
    latest_calls = calls_qs.order_by('-call_date')[:100]

    context = {
        'form': form,
        'start_date': start_date,
        'end_date': end_date,
        'calls': latest_calls,
        'repeated_calls': repeated_calls,
    }

    return render(request, 'callchecker/recent_calls.html', context)



def call_termination_reasons(request):
    form = YourDateRangeForm(request.GET or None)
    calls_qs = VicidialCloserLog.objects.all()

    if form.is_valid():
        start_date = form.cleaned_data.get('start_date')
        end_date = form.cleaned_data.get('end_date')
        if start_date:
            start_date = timezone.make_aware(datetime.datetime.combine(start_date, datetime.time.min))
            calls_qs = calls_qs.filter(call_date__gte=start_date)
        if end_date:
            end_date = timezone.make_aware(datetime.datetime.combine(end_date, datetime.time.max))
            calls_qs = calls_qs.filter(call_date__lte=end_date)

    calls_qs = calls_qs.order_by('-call_date')

    paginator = Paginator(calls_qs, 50)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    context = {
        'recent_calls': page_obj,
        'form': form,
    }
    return render(request, 'callchecker/call_termination_reasons.html', context)

