import logging
logging.basicConfig(filename='/tmp/wsgi_debug.log', level=logging.DEBUG)
logging.debug("WSGI script started")

import os
from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'vicidial_dashboard.settings')

application = get_wsgi_application()

logging.debug("WSGI application loaded")

